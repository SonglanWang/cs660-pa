#ifndef DB_HISTOGRAM_H
#define DB_HISTOGRAM_H

namespace db {
    class Histogram {

    };
}

#endif
