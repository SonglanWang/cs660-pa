#include <db/LogicalJoinNode.h>

using namespace db;
